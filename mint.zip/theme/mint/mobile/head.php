<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

include_once(G5_THEME_PATH.'/head.sub.php');
include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');

add_javascript('<script src="'.G5_THEME_JS_URL.'/simpleMobileMenu.js"></script>', 10);
add_stylesheet('<link rel="stylesheet" href="'.G5_THEME_CSS_URL.'/simpleMobileMenu.css">', 0);
add_javascript('<script src="'.G5_THEME_JS_URL.'/respond.min.js"></script>', 1);
?>
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<header class="cf" id="hd">
    <h1 id="hd_h1"><?php echo $g5['title'] ?></h1>

    <div class="to_content"><a href="#container">본문 바로가기</a></div>
    
    <?php
    if(defined('_INDEX_')) { // index에서만 실행
        include G5_MOBILE_PATH.'/newwin.inc.php'; // 팝업레이어
    } ?>

    <div id="hd_wr">
        <div id="logo"><a href="<?php echo G5_URL ?>"><img src="<?php echo G5_THEME_IMG_URL ?>/logo.gif" alt="<?php echo $config['cf_title']; ?>"></a></div>


        <!--검색-->
        <button type="button" id="hd_sch_open" class="hd_opener">검색<span class="sound_only"> 열기</span></button>

            <div id="hd_sch" class="hd_div">
                <h2>사이트 내 전체검색</h2>
                <form name="fsearchbox" action="<?php echo G5_BBS_URL ?>/search.php" onsubmit="return fsearchbox_submit(this);" method="get">
                <input type="hidden" name="sfl" value="wr_subject||wr_content">
                <input type="hidden" name="sop" value="and">
                <label for="sch_stx" id="sch_stc_label">검색어<strong class="sound_only"> 필수</strong></label>
                <input type="text" name="stx" id="sch_stx" required maxlength="20">
                <input type="submit" value="검색" id="sch_submit">
                </form>

                <script>
                function fsearchbox_submit(f)
                {
                    if (f.stx.value.length < 2) {
                        alert("검색어는 두글자 이상 입력하십시오.");
                        f.stx.select();
                        f.stx.focus();
                        return false;
                    }

                    // 검색에 많은 부하가 걸리는 경우 이 주석을 제거하세요.
                    var cnt = 0;
                    for (var i=0; i<f.stx.value.length; i++) {
                        if (f.stx.value.charAt(i) == ' ')
                            cnt++;
                    }

                    if (cnt > 1) {
                        alert("빠른 검색을 위하여 검색어에 공백은 한개만 입력할 수 있습니다.");
                        f.stx.select();
                        f.stx.focus();
                        return false;
                    }

                    return true;
                }

                $(function() {
                var $sch = $('#sch_stx');   //검색 input
                var $sch_label = $('#sch_stc_label');    //검색 label
                if ($sch.attr('value') == "") $sch_label.css('visibility','visible');
                else  $sch_label.css('visibility','hidden');

                $sch.focus(function() {
                    $sch_label.css('visibility','hidden');
                });
                $sch.blur(function() {
                    $this = $(this);
                    if ($this.attr('id') == "sch_stx" && $this.attr('value') == "") $sch_label.css('visibility','visible');
                });
                });
                </script>
                
            </div>

            <script>
            $(function () {
                $(".hd_opener").on("click", function() {
                    var $this = $(this);
                    var $hd_layer = $this.next(".hd_div");

                    if($hd_layer.is(":visible")) {
                        $hd_layer.hide();
                        $this.find("span").text("열기");
                    } else {
                        var $hd_layer2 = $(".hd_div:visible");
                        $hd_layer2.prev(".hd_opener").find("span").text("열기");
                        $hd_layer2.hide();

                        $hd_layer.show();
                        $this.find("span").text("닫기");
                    }
                });

                $(".hd_closer").on("click", function() {
                    var idx = $(".hd_closer").index($(this));
                    $(".hd_div:visible").hide();
                    $(".hd_opener:eq("+idx+")").find("span").text("열기");
                });
            });

            </script>
        <!--검색-->
        <div class="navigation">
            <nav>
                <a href="javascript:void(0)" class="smobitrigger ion-navicon-round"><span>Menu</span></a>
                <ul class="mobimenu">
                    <?php if ($is_member) { ?>
                    <?php if ($is_admin) {  ?>
                    <li class="menu_admin"><a href="<?php echo G5_ADMIN_URL ?>"><b>관리자</b></a></li>
                    <?php }  ?>
                    <li class="menu_edit"><a href="<?php echo G5_BBS_URL ?>/member_confirm.php?url=<?php echo G5_BBS_URL ?>/register_form.php">정보수정</a></li>

                    <li class="menu_logout"><a href="<?php echo G5_BBS_URL ?>/logout.php" id="snb_logout">로그아웃</a></li>
                    <?php } else { ?>
                    <li class="menu_login"><a href="<?php echo G5_BBS_URL ?>/login.php" id="snb_login">로그인</a></li>
                    <?php } ?>
                    <?php
                $sql = " select *
                            from {$g5['menu_table']}
                            where me_mobile_use = '1'
                              and length(me_code) = '2'
                            order by me_order, me_id ";
                $result = sql_query($sql, false);

                for($i=0; $row=sql_fetch_array($result); $i++) {
                ?>
                    <li class="gnb_1dli" style="z-index:<?php echo $gnb_zindex--; ?>">
                        <?php
                        $submenus = '';

                        $sql2 = " select *
                                    from {$g5['menu_table']}
                                    where me_mobile_use = '1'
                                      and length(me_code) = '4'
                                      and substring(me_code, 1, 2) = '{$row['me_code']}'
                                    order by me_order, me_id ";
                        $result2 = sql_query($sql2);

                        for ($k=0; $row2=sql_fetch_array($result2); $k++) {
                            if($k == 0)
                               $submenus .= '<button type="button" class="gnb_op">하위메뉴</button><ul class="gnb_2dul">'.PHP_EOL;

                            $submenus .= '<li class="gnb_2dli"><a href="'.$row2['me_link'].'" target="_'.$row2['me_target'].'" class="gnb_2da">'.$row2['me_name'].'</a></li>'.PHP_EOL;
                        }

                        if($k > 0)
                            $submenus .= '</ul>'.PHP_EOL;

                        if($submenus)
                            $gnb_class = 'gnb_1da gnb_bg';
                        else
                            $gnb_class = 'gnb_1da';
                        ?>
                        <a href="<?php echo $row['me_link']; ?>" target="_<?php echo $row['me_target']; ?>" class="<?php echo $gnb_class; ?>"><?php echo $row['me_name'] ?></a>
                        <?php echo $submenus; ?>
                    </li>
                <?php
                }

                if ($i == 0) {  ?>
                    <li id="gnb_empty">메뉴 준비 중입니다.<?php if ($is_admin) { ?> <br><a href="<?php echo G5_ADMIN_URL; ?>/menu_list.php">관리자모드 &gt; 환경설정 &gt; 메뉴설정</a>에서 설정하세요.<?php } ?></li>
                <?php } ?>
                </ul>
            </nav>
        </div>
    </div>
</header>
<script>

jQuery(document).ready(function($) {
    $(".smobitrigger").smplmnu();
});

$(function(){
    $(".gnb_op").click(function(){
        $(this).next().slideToggle(300).siblings(".gnb_2dul").slideUp("slow");
    });
    $("#wrapper").on("click", function() {
        $(".gnb_2dul").fadeOut();
    });
});

</script>
<hr>

<div id="wrapper">
    
    <div id="container">
        <?php if ((!$bo_table || $w == 's' ) && !defined("_INDEX_")) { ?><div id="container_title"><?php echo $g5['title'] ?></div><?php } ?>
        