Theme Name: 민트
Theme URI: http://theme.sir.co.kr/gnuboard5/demo/mint
Maker: SIR
Maker URI: http://sir.co.kr
Version: 1.0.0
Detail: 민트테마는 모바일전용 반응형 테마입니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html