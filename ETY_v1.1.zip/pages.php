<?php

include_once('./_common.php');

include_once(G5_THEME_PATH.'/head.php');

?>

내용

<?php 

include_once(G5_THEME_PATH.'/tail.php');

?>